import network
import urequests
import time
from machine import TouchPad, Pin


SSID = "Inserte nombre de red wifi"
PASSWORD = "Inserte contraseña de la red wifi"

# URL del Webhook
URL = "Inserte la URL del servicio Webhook que esta usando"

# ---- CONEXIÓN WIFI ----
wifi = network.WLAN(network.STA_IF)
wifi.active(True)
wifi.connect(SSID, PASSWORD)

print("Conectando a WiFi...", end="")
while not wifi.isconnected():
    print(".", end="")
    time.sleep(0.5)
print("\nConectado:", wifi.ifconfig())

# ----PIN TOUCH ----
touch_pin = TouchPad(Pin(13)) 
touch_pin.config(300)  # sensibilidad

# ---- BUCLE PRINCIPAL ----
umbral = 850  # valor de activación
print("Inicio del monitoreo del pin touch...")

while True:
    valor = touch_pin.read()
    print("Lectura touch:", valor)
    if valor < umbral:
        print("¡Toque detectado! Enviando notificación...")
        try:
            response = urequests.get(URL)
            print("Respuesta URL:", response.text)
            response.close()
        except Exception as e:
            print("Error al enviar:", e)
        time.sleep(10)
    time.sleep(0.5)

