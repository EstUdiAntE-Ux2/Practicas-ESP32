import network
import usocket as socket
import time
from machine import TouchPad, Pin

SSID = "Inserte nombre de la red wifi"
PASSWORD = "Inserte la contraseña de la red wifi"

# --- CONEXIÓN A WIFI ---
wifi = network.WLAN(network.STA_IF)
wifi.active(True)
wifi.connect(SSID, PASSWORD)
print("Conectando a WiFi...", end="")
while not wifi.isconnected():
    print(".", end="")
    time.sleep(0.5)
print("\n✅ Conectado:", wifi.ifconfig())

# --- CONFIGURAR TOUCH ---
touch = TouchPad(Pin(13))
umbral = 400 

# --- CONFIGURACIÓN DEL SERVIDOR ---
SERVER_IP = "Ingrese la direccion IP del PC"  
SERVER_PORT = 5000

# --- FUNCIÓN PARA ENVIAR DATOS AL SERVIDOR ---
def enviar_mensaje(msg):
    try:
        s = socket.socket()
        s.connect((SERVER_IP, SERVER_PORT))
        s.send(msg.encode())
        s.close()
        print("📤 Enviado:", msg)
    except Exception as e:
        print("❌ Error al enviar:", e)


print("📡 Monitoreando pin táctil (GPIO13)...")
while True:
    lectura = touch.read()
    print("Lectura:", lectura)
    if lectura < umbral:
        enviar_mensaje("TOQUE detectado!")
        time.sleep(2) 
    time.sleep(0.5)
