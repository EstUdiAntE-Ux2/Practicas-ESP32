import network
import time
from umqtt.simple import MQTTClient
import random

# ---- CONFIGURACIÓN DE WIFI ----
SSID = "Ingrese red Wi-fi"
PASSWORD = "Ingrese la contraseña de su red Wifi"

print("Conectando a WiFi...", end="")
wifi = network.WLAN(network.STA_IF)
wifi.active(True)
wifi.connect(SSID, PASSWORD)
while not wifi.isconnected():
    print(".", end="")
    time.sleep(0.5)
print("\n✅ Conectado a WiFi:", wifi.ifconfig())

# ---- CONFIGURACIÓN MQTT ----
MQTT_BROKER = "broker.hivemq.com"
MQTT_PORT = 1883
MQTT_TOPIC = "esp32/sensor/practica"
CLIENT_ID = "sensor_esp32_01"  # ID para el sensor

# ---- CONEXIÓN AL BROKER ----
client = MQTTClient(CLIENT_ID, MQTT_BROKER, port=MQTT_PORT)
client.connect()
print("📡 Conectado al broker MQTT:", MQTT_BROKER)

# ---- SIMULACIÓN DE SENSOR ----
while True:
    lectura = round(random.uniform(20.0, 30.0), 2)  # simulando lectura
    bateria = random.randint(20, 100)               # simulando porcentaje batería
    mensaje = f'{{"id":"{CLIENT_ID}","lectura":{lectura},"bateria":{bateria}}}'
    
    client.publish(MQTT_TOPIC, mensaje)
    print("📤 Publicado:", mensaje)
    
    time.sleep(10)  